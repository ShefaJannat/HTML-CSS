changeColor(){
  var dd1= document.getElementById("d1");
  dd1.className="pinkback";
  var dd2 =document.getElementById("d2");
  dd2.className="blueback";
}