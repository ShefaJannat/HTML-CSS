function upload(){
  //get input from text input
  var fileinput=document.getElementById("finput");
  var filename= fileinput.value;
  //alert displaying text
  alert("You chose"+filename);
}