function dolime(){
  var dd1=document.getElementById("d1");
  dd1.style.backgroundColor="lime";
}
function dored(){
  var dd1=document.getElementById("d1");
  dd1.style.backgroundColor="red";
  var ctx= dd1.getContext("2d");
  ctx.fillStyle="yellow";
  ctx.fillRect(10,10,40,40);
   ctx.fillRect(80,10,40,80);
  ctx.fillStyle="black";
  //dd1.clearRect(0,0,canvas.width,canvas.height);
  ctx.font="30px Arial";
  ctx.fillText("Hello",10,80);
  
}