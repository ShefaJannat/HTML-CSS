function upload(){
  var fileinput=document.getElementById("finput");
var image = new SimpleImage(fileinput);
  var canvas=document.getElementById("can");
  image.drawTo(canvas);
  var filename=fileinput.value;
  alert("You chose"+filename);
  image.drawTo(canvas);
}